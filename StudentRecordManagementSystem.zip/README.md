# Student Record Management System (Maven / Eclipse)

A Java Servlet + JSP + MySQL CRUD web application packaged as a Maven WAR.

## Requirements
- JDK 17+
- Eclipse IDE for Enterprise Java and Web Developers
- Apache Tomcat 10.1 (Jakarta Servlet 6)
- MySQL Server 8+

## Database setup
Run `database/student_records.sql` in MySQL Workbench. Update credentials in
`src/main/java/com/student/util/DBConnection.java` to match your local MySQL setup.

## Import and run in Eclipse
1. Extract this ZIP.
2. Eclipse: **File → Import → Maven → Existing Maven Projects**.
3. Select the extracted project directory and finish. Allow Maven to download dependencies.
4. Add Tomcat 10.1: **Window → Show View → Servers → New Server**.
5. Right-click project → **Run As → Run on Server**.
6. Open `http://localhost:8080/StudentRecordManagementSystem/`.

## Features
- List and search students by name, email, or course
- Add, edit, and delete records
- Input validation and parameterized SQL
- Responsive JSP interface

## Notes
This sample is intended for academic/demo use. Change database credentials and add
authentication/CSRF protection before deploying publicly.
