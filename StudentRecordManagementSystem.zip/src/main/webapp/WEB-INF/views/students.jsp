<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Student Records</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body><main class="container">
<header><div><p class="eyebrow">ACADEMIC PORTAL</p><h1>Student Records</h1><p class="muted">Manage student information in one place.</p></div><a class="button" href="${pageContext.request.contextPath}/student/new">+ Add Student</a></header>
<c:if test="${param.success=='1'}"><div class="notice">Student record saved successfully.</div></c:if><c:if test="${param.deleted=='1'}"><div class="notice">Student record deleted.</div></c:if>
<form class="search" method="get" action="${pageContext.request.contextPath}/students"><input name="q" value="<c:out value='${query}'/>" placeholder="Search roll number, name, email, course"><button>Search</button><a href="${pageContext.request.contextPath}/students">Reset</a></form>
<section class="panel"><div class="panel-head"><h2>All Students</h2><span class="count"><c:out value="${students.size()}"/> records</span></div>
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Roll No.</th><th>Name</th><th>Email</th><th>Phone</th><th>Course</th><th>Actions</th></tr></thead><tbody>
<c:forEach var="s" items="${students}"><tr><td><c:out value="${s.id}"/></td><td><c:out value="${s.rollNo}"/></td><td><strong><c:out value="${s.fullName}"/></strong></td><td><c:out value="${s.email}"/></td><td><c:out value="${s.phone}"/></td><td><span class="tag"><c:out value="${s.course}"/></span></td><td class="actions"><a href="${pageContext.request.contextPath}/student/edit?id=${s.id}">Edit</a><form method="post" action="${pageContext.request.contextPath}/student/delete" onsubmit="return confirm('Delete this student record?')"><input type="hidden" name="id" value="${s.id}"><button class="link danger">Delete</button></form></td></tr></c:forEach>
<c:if test="${empty students}"><tr><td colspan="7" class="empty">No student records found.</td></tr></c:if>
</tbody></table></div></section><footer>Student Record Management System · Maven Web Application</footer></main></body></html>
