<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><c:out value="${formTitle}"/></title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head><body><main class="container narrow">
<a class="back" href="${pageContext.request.contextPath}/students">← Back to records</a><section class="panel form-panel"><p class="eyebrow">STUDENT DETAILS</p><h1><c:out value="${formTitle}"/></h1><p class="muted">Fields marked * are required.</p>
<c:if test="${not empty error}"><div class="error"><c:out value="${error}"/></div></c:if>
<form method="post" action="${pageContext.request.contextPath}/student/save" class="fields">
<input type="hidden" name="id" value="${student.id}">
<label>Roll Number *<input name="rollNo" required maxlength="30" value="<c:out value='${student.rollNo}'/>"></label>
<label>Full Name *<input name="fullName" required maxlength="100" value="<c:out value='${student.fullName}'/>"></label>
<label>Email Address *<input type="email" name="email" required maxlength="120" value="<c:out value='${student.email}'/>"></label>
<label>Phone Number<input name="phone" maxlength="20" value="<c:out value='${student.phone}'/>"></label>
<label>Course *<input name="course" required maxlength="100" value="<c:out value='${student.course}'/>"></label>
<div class="form-actions"><button class="button">Save Student</button><a class="cancel" href="${pageContext.request.contextPath}/students">Cancel</a></div>
</form></section></main></body></html>
