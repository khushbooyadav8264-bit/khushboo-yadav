package com.student.model;

public class Student {
    private int id;
    private String rollNo, fullName, email, phone, course;

    public Student() {}
    public Student(int id, String rollNo, String fullName, String email, String phone, String course) {
        this.id=id; this.rollNo=rollNo; this.fullName=fullName; this.email=email; this.phone=phone; this.course=course;
    }
    public int getId(){return id;} public void setId(int id){this.id=id;}
    public String getRollNo(){return rollNo;} public void setRollNo(String v){rollNo=v;}
    public String getFullName(){return fullName;} public void setFullName(String v){fullName=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
    public String getCourse(){return course;} public void setCourse(String v){course=v;}
}
