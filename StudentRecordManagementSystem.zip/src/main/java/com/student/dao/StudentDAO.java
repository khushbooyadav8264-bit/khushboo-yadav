package com.student.dao;

import com.student.model.Student;
import com.student.util.DBConnection;
import java.sql.*;
import java.util.*;

public class StudentDAO {
    public List<Student> findAll(String query) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM students WHERE roll_no LIKE ? OR full_name LIKE ? OR email LIKE ? OR course LIKE ? ORDER BY id DESC";
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            String q="%"+(query==null?"":query.trim())+"%";
            for(int i=1;i<=4;i++) p.setString(i,q);
            try(ResultSet r=p.executeQuery()){ while(r.next()) list.add(map(r)); }
        }
        return list;
    }
    public Student findById(int id) throws SQLException {
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement("SELECT * FROM students WHERE id=?")) {
            p.setInt(1,id); try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}
        }
    }
    public void insert(Student s) throws SQLException {
        String sql="INSERT INTO students(roll_no,full_name,email,phone,course) VALUES(?,?,?,?,?)";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)){
            bind(p,s); p.executeUpdate();
        }
    }
    public void update(Student s) throws SQLException {
        String sql="UPDATE students SET roll_no=?,full_name=?,email=?,phone=?,course=? WHERE id=?";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)){
            bind(p,s); p.setInt(6,s.getId()); p.executeUpdate();
        }
    }
    public void delete(int id) throws SQLException {
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement("DELETE FROM students WHERE id=?")){
            p.setInt(1,id); p.executeUpdate();
        }
    }
    private void bind(PreparedStatement p,Student s)throws SQLException{
        p.setString(1,s.getRollNo());p.setString(2,s.getFullName());p.setString(3,s.getEmail());p.setString(4,s.getPhone());p.setString(5,s.getCourse());
    }
    private Student map(ResultSet r)throws SQLException{
        return new Student(r.getInt("id"),r.getString("roll_no"),r.getString("full_name"),r.getString("email"),r.getString("phone"),r.getString("course"));
    }
}
