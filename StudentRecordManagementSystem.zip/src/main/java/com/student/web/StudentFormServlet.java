package com.student.web;
import com.student.dao.StudentDAO; import com.student.model.Student;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*;
import java.io.IOException; import java.sql.SQLException;

@WebServlet({"/student/new","/student/edit"})
public class StudentFormServlet extends HttpServlet {
 private final StudentDAO dao=new StudentDAO();
 protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
  String path=req.getServletPath();
  try{
   Student s=new Student();
   if(path.endsWith("edit")){int id=Integer.parseInt(req.getParameter("id")); s=dao.findById(id); if(s==null){res.sendError(404);return;}}
   req.setAttribute("student",s); req.setAttribute("formTitle",path.endsWith("edit")?"Edit Student":"Add Student");
   req.getRequestDispatcher("/WEB-INF/views/student-form.jsp").forward(req,res);
  }catch(NumberFormatException e){res.sendError(400);}catch(SQLException e){throw new ServletException(e);}
 }
}
