package com.student.web;
import com.student.dao.StudentDAO; import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*;
import java.io.IOException; import java.sql.SQLException;

@WebServlet("/student/delete")
public class StudentDeleteServlet extends HttpServlet {
 protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
  try{int id=Integer.parseInt(req.getParameter("id"));new StudentDAO().delete(id);res.sendRedirect(req.getContextPath()+"/students?deleted=1");}
  catch(NumberFormatException e){res.sendError(400);}catch(SQLException e){throw new ServletException(e);}
 }
}
