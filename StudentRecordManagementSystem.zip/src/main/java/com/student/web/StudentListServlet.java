package com.student.web;
import com.student.dao.StudentDAO;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*;
import java.io.IOException; import java.sql.SQLException;

@WebServlet("/students")
public class StudentListServlet extends HttpServlet {
    private final StudentDAO dao=new StudentDAO();
    protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        try { String q=req.getParameter("q"); req.setAttribute("query",q==null?"":q); req.setAttribute("students",dao.findAll(q)); req.getRequestDispatcher("/WEB-INF/views/students.jsp").forward(req,res); }
        catch(SQLException e){throw new ServletException(e);}
    }
}
