package com.student.web;
import com.student.dao.StudentDAO; import com.student.model.Student;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*;
import java.io.IOException; import java.sql.SQLException;

@WebServlet("/student/save")
public class StudentSaveServlet extends HttpServlet {
 private final StudentDAO dao=new StudentDAO();
 protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
  req.setCharacterEncoding("UTF-8");
  String roll=req.getParameter("rollNo"), name=req.getParameter("fullName"), email=req.getParameter("email"), phone=req.getParameter("phone"), course=req.getParameter("course"), id=req.getParameter("id");
  if(blank(roll)||blank(name)||blank(email)||blank(course)||!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")){
   req.setAttribute("error","Please provide roll number, name, valid email, and course."); req.setAttribute("student",new Student(parseId(id),roll,name,email,phone,course)); req.setAttribute("formTitle","Edit".equals(req.getParameter("mode"))?"Edit Student":"Add Student"); req.getRequestDispatcher("/WEB-INF/views/student-form.jsp").forward(req,res); return;
  }
  Student s=new Student(parseId(id),roll.trim(),name.trim(),email.trim(),phone==null?"":phone.trim(),course.trim());
  try{if(s.getId()>0)dao.update(s);else dao.insert(s);res.sendRedirect(req.getContextPath()+"/students?success=1");}
  catch(SQLException e){req.setAttribute("error","Could not save record. Check that roll number/email are unique and database settings are correct.");req.setAttribute("student",s);req.setAttribute("formTitle",s.getId()>0?"Edit Student":"Add Student");req.getRequestDispatcher("/WEB-INF/views/student-form.jsp").forward(req,res);}
 }
 private boolean blank(String s){return s==null||s.trim().isEmpty();}
 private int parseId(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
}
